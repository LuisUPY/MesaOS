from PIL import Image, ImageDraw, ImageFont, ImageFilter, ImageOps
import numpy as np, cv2, math, subprocess, os, sys, json, wave
from pathlib import Path
ROOT=Path(__file__).resolve().parent
os.chdir(ROOT)
W,H,FPS=1080,1920,30
DUR=[4.2,5.4,5.4,4.8,4.8,5.4,6.0]
START=np.cumsum([0]+DUR).tolist()
TOTAL=START[-1]
PAPER=(245,245,241); INK=(24,25,24); MUTED=(111,115,111); GREEN=(78,119,94)
REG='/usr/share/fonts/opentype/urw-base35/NimbusSans-Regular.otf'
BOLD='/usr/share/fonts/opentype/urw-base35/NimbusSans-Bold.otf'
SERIF='/usr/share/fonts/opentype/urw-base35/P052-Roman.otf'
FONTS={}
TEXTCACHE={}
def font(n,style='reg'):
 k=(n,style)
 if k not in FONTS: FONTS[k]=ImageFont.truetype({'reg':REG,'bold':BOLD,'serif':SERIF}[style],n)
 return FONTS[k]
def ease(x):
 x=max(0,min(1,x)); return 1-(1-x)**3
def lerp(a,b,t):return a+(b-a)*t
def alpha(im,a):
 if a>=.999:return im
 out=im.copy();out.putalpha(out.getchannel('A').point(lambda v:int(v*max(0,a))));return out
def rounded(im,r):
 im=im.convert('RGBA');m=Image.new('L',im.size,0);ImageDraw.Draw(m).rounded_rectangle((0,0,im.width-1,im.height-1),radius=r,fill=255);im.putalpha(m);return im
def paste(out,im,x,y,a=1):
 if a>0:out.paste(alpha(im,a),(int(x),int(y)),alpha(im,a))
def txt(text,n,style='reg',fill=INK):
 key=(text,n,style,tuple(fill))
 if key in TEXTCACHE:return TEXTCACHE[key]
 f=font(n,style);box=f.getbbox(text);size=(int(f.getlength(text))+8,box[3]-box[1]+10)
 im=Image.new('RGBA',size,(0,0,0,0));ImageDraw.Draw(im).text((2,3-box[1]),text,font=f,fill=fill);TEXTCACHE[key]=im;return im
def put(out,text,x,y,n=36,style='reg',fill=INK,a=1):
 paste(out,txt(text,n,style,fill),x,y,a)
def pill(text,n=27,bg=(255,255,255),fg=INK,pad=24,h=60):
 textim=txt(text,n,'reg',fg);o=Image.new('RGBA',(textim.width+pad*2,h),(0,0,0,0));d=ImageDraw.Draw(o);d.rounded_rectangle((0,0,o.width-1,h-1),h//2,fill=bg);paste(o,textim,pad,(h-textim.height)//2);return o
def resizew(im,w):
 return im.resize((int(w),int(im.height*w/im.width)),Image.Resampling.LANCZOS)
def card(im,w,r=24):
 return rounded(resizew(im,w),r)
INPUT={k:Image.open('inputs/'+k+'.png').convert('RGBA') for k in ['hero','logo','menu','order','history','receipt']}
LOGO=INPUT['logo'].crop(INPUT['logo'].getbbox())
LOGOS={220:resizew(LOGO,220),480:resizew(LOGO,480)}
Y,X=np.mgrid[0:H,0:W].astype(np.float32)
def background(dark=False):
 if dark:
  g=np.exp(-(((X-750)/1000)**2+((Y-900)/1100)**2)); arr=np.zeros((H,W,3),np.uint8)
  for i,v in enumerate([18,20,20]):arr[:,:,i]=v+g*9
 else:
  g=np.exp(-(((X-150)/800)**2+((Y-1100)/1200)**2));arr=np.zeros((H,W,3),np.uint8)
  for i,v in enumerate(PAPER):arr[:,:,i]=v-g*[7,5,2][i]
 im=Image.fromarray(arr).convert('RGBA');d=ImageDraw.Draw(im)
 col=(48,51,50,255) if dark else (227,230,224,255)
 for j in range(3):d.arc((-670+j*70,600+j*90,1460+j*80,2280+j*80),200,335,fill=col,width=2)
 return im
BG=[background(),background(True)]
SHADOW={}
def shadow(w,h,r=30):
 key=(w,h,r)
 if key not in SHADOW:
  o=Image.new('RGBA',(w+80,h+100));d=ImageDraw.Draw(o);d.rounded_rectangle((40,30,w+40,h+30),r,fill=(15,20,17,36));SHADOW[key]=o.filter(ImageFilter.GaussianBlur(19))
 return SHADOW[key]
def picture(out,im,x,y,a=1):
 paste(out,shadow(im.width,im.height),x-40,y-18,a);paste(out,im,x,y,a)
TEXT=[
 (['Tu restaurante.','Bajo control.'],'Tu menú. Tu equipo. Tu ritmo.','SOFTWARE PARA RESTAURANTES'),
 (['Tu menú.','A la mano.'],'Encuentra. Elige. Añade al pedido.','01 / MENÚ'),
 (['Cada pedido,','a tu manera.'],'Extras y notas de preparación.','02 / EXTRAS Y NOTAS'),
 (['Cada mesa,','a la vista.'],'Menú, selección y pedidos abiertos.','03 / PEDIDOS'),
 (['Cuentas','claras.'],'Cada detalle, también en el ticket.','04 / CUENTA'),
 (['Tus números.','Con claridad.'],'Consulta las ventas y pedidos de cada día.','05 / HISTORIAL'),
 (['El orden,','en su forma','más simple.'],'Tecnología que sigue tu ritmo.','mesaOS / BASIC')
]
STATIC={}
STATIC['hero']=card(INPUT['hero'],950,28)
STATIC['screen']=card(INPUT['order'],946,28)
STATIC['tables']=card(INPUT['order'].crop((22,628,780,770)),920,22)
STATIC['history']=card(INPUT['history'].crop((310,136,1150,710)),924,28)
STATIC['receipt']=resizew(INPUT['receipt'],580)
STATIC['receipt_mask']=Image.new('L',(580,850),0)
ImageDraw.Draw(STATIC['receipt_mask']).rounded_rectangle((0,0,579,849),28,fill=255)
VIDEOS={}
def getlive(key,at):
 if key not in VIDEOS: VIDEOS[key]=cv2.VideoCapture(key+'_clip.mp4')
 cap=VIDEOS[key];frameidx=round(at*FPS)
 if abs(cap.get(cv2.CAP_PROP_POS_FRAMES)-frameidx)>.1:cap.set(cv2.CAP_PROP_POS_FRAMES,frameidx)
 ok,f=cap.read()
 if not ok:
  cap.set(cv2.CAP_PROP_POS_FRAMES,max(0,cap.get(cv2.CAP_PROP_FRAME_COUNT)-1));ok,f=cap.read()
 if not ok:raise RuntimeError('Unable to decode demo')
 return rounded(Image.fromarray(cv2.cvtColor(f,cv2.COLOR_BGR2RGB)),24)
def chrome(out,i,t,dark=False):
 c=(250,250,246) if dark else INK
 if not dark:paste(out,LOGOS[220],80,150)
 else:
  put(out,'mesaOS / BASIC',80,158,27,'reg',c)
 put(out,'TU NEGOCIO. TU RITMO.',80,1582,22,'reg',(155,159,153) if dark else MUTED)
 put(out,f'{i+1:02d} / 07',850,1582,22,'reg',(155,159,153) if dark else MUTED)
 dr=ImageDraw.Draw(out)
 dr.line((80,1640,1000,1640),fill=(62,65,62) if dark else (216,221,214),width=2)
 dr.line((80,1640,80+920*min(1,(START[i]+t)/TOTAL),1640),fill=(218,228,216) if dark else (48,73,57),width=3)
def title(out,i,t):
 lines,sub,kicker=TEXT[i];dark=i==6;fill=(246,246,241) if dark else INK
 if i==6:
  k=txt('SIMPLICIDAD Y CONTROL',26,'reg',(168,174,167));paste(out,k,80,298,ease(t/.45))
  for j,s in enumerate(lines):
   e=ease((t-.14-j*.09)/.6);put(out,s,78,490+j*129+(1-e)*40,118,'serif',fill,e)
  e=ease((t-.6)/.6);put(out,sub,80,955+(1-e)*20,35,'reg',(173,180,173),e)
 else:
  e=ease(t/.4);put(out,kicker,80,294+(1-e)*24,25,'reg',MUTED,e)
  for j,s in enumerate(lines):
   e=ease((t-.07-j*.08)/.6);put(out,s,76,365+j*112+(1-e)*35,102,'serif' if j==1 else 'reg',fill,e)
  e=ease((t-.35)/.55);put(out,sub,80,615+(1-e)*20,33,'reg',MUTED,e)
def scene(i,t):
 out=BG[1 if i==6 else 0].copy();chrome(out,i,t,i==6)
 title(out,i,t)
 e=ease((t-.25)/.8);dy=(1-e)*80
 p=max(0,min(1,t/DUR[i]))
 if i==0:
  im=STATIC['hero'];s=1+.035*p;im=im.resize((round(im.width*s),round(im.height*s)),Image.Resampling.BICUBIC)
  picture(out,im,(W-im.width)/2,825+dy+math.sin(t*.8)*5,e)
  put(out,'Diseñado para restaurantes.',80,1490,31,'reg',MUTED,ease((t-.7)/.5))
 elif i==1:
  im=getlive('menu',t)
  picture(out,im,70,755+dy,e)
  label=pill('Catálogo real de la demo',26,(232,236,229),(67,88,70),26,57)
  paste(out,label,80,1455,ease((t-.7)/.5))
 elif i==2:
  im=getlive('extras',t)
  picture(out,im,100,725+dy,e)
  put(out,'Preferencias que acompañan al pedido.',80,1510,28,'reg',MUTED,ease((t-.7)/.5))
 elif i==3:
  im=STATIC['screen'];picture(out,im,67,745+dy,e)
  tabs=STATIC['tables'];picture(out,tabs,80,1370+dy*.45,e)
 elif i==4:
  im=STATIC['receipt'];scroll=round(lerp(0,410,ease(max(0,(t-1)/3.5))))
  crop=im.crop((0,scroll,580,scroll+850));crop.putalpha(STATIC['receipt_mask'])
  picture(out,crop,250,715+dy,e)
  # Receipt remains the user's original, with a camera move across it.
 elif i==5:
  im=STATIC['history'];picture(out,im,78,775+dy,e)
  label=pill('Datos de demostración',26,(232,236,229),(67,88,70),26,57)
  paste(out,label,80,1480,ease((t-.7)/.5))
 else:
  panel=Image.new('RGBA',(490,182));ImageDraw.Draw(panel).rounded_rectangle((0,0,489,181),26,fill=(247,247,242))
  mark=resizew(LOGO,398);paste(panel,mark,(490-mark.width)/2,(182-mark.height)/2)
  picture(out,panel,80,1110+dy*.4,e)
  et=ease((t-.7)/.5)
  cta=pill('Explora la demo  ↗',38,(244,247,239),INK,36,94)
  paste(out,cta,80,1350+(1-et)*20,et)
  put(out,'mesa-os.whop.site',80,1482,36,'reg',(210,217,209),et)
 return out
def makeaudio():
 sr=48000;n=int(TOTAL*sr);out=np.zeros((n,2),np.float32);rng=np.random.default_rng(24)
 def add(signal,start,gain=.1,pan=0):
  j=int(start*sr)
  if j<0:return
  sig=signal[:max(0,n-j)]*gain
  if len(sig)==0:return
  out[j:j+len(sig),0]+=sig*math.sqrt((1-pan)/2)
  out[j:j+len(sig),1]+=sig*math.sqrt((1+pan)/2)
 def tone(m,dur=1.1):
  tt=np.arange(int(sr*dur))/sr;f=440*2**((m-69)/12)
  env=(1-np.exp(-tt*130))*np.exp(-tt*3.0)
  return (.74*np.sin(2*np.pi*f*tt)+.2*np.sin(2*np.pi*f*2*tt)+.06*np.sin(2*np.pi*f*3*tt))*env
 beat=.6;chords=[[50,57,60,64],[46,53,57,60],[53,60,64,69],[48,55,62,64]]
 for b in range(int(TOTAL/beat)):
  t=b*beat;ch=chords[(b//4)%4]
  if b%4==0:
   for j,m in enumerate(ch):
    tt=np.arange(int(sr*3.0))/sr;f=440*2**((m-69)/12);env=(1-np.exp(-tt*4))*np.exp(-tt*.9)
    sig=(np.sin(2*np.pi*f*tt)+.3*np.sin(2*np.pi*f*1.0015*tt))*env
    add(sig,t,.038,(j-1.5)*.38)
  if b%2==0:add(tone(ch[0]-12,1.5),t,.13,0)
  m=ch[[2,1,3,1][b%4]]+12;add(tone(m,1.6),t+.3,.055,(-1 if b%2 else 1)*.35)
  tt=np.arange(int(sr*.28))/sr;phase=2*np.pi*(47*tt+55*.038*(1-np.exp(-tt/.038)))
  kick=np.sin(phase)*np.exp(-tt*18)
  add(kick,t,.18,0)
  if b%2:
   tt=np.arange(int(sr*.16))/sr;noise=rng.standard_normal(len(tt))
   noise=np.concatenate(([0],np.diff(noise)));add(noise*np.exp(-tt*38),t,.018,0)
  for off in [0,.3]:
   tt=np.arange(int(sr*.07))/sr;noise=rng.standard_normal(len(tt));noise=np.concatenate(([0],np.diff(noise)))
   add(noise*np.exp(-tt*75),t+off,.010,(-1 if b%2 else 1)*.4)
 for t in START[1:-1]:
  tt=np.arange(int(sr*.35))/sr;noise=rng.standard_normal(len(tt));env=np.sin(np.pi*tt/.35)**2
  noise=np.convolve(noise,np.ones(30)/30,mode='same');add(noise*env,t-.13,.045,.2)
 # A short stereo tail makes the electric piano notes soft without a library track.
 for delay,g in [(.125,.13),(.25,.08)]:
  sh=int(delay*sr);out[sh:]+=out[:-sh,::-1]*g
 fade=np.ones(n);fade[:int(sr*.5)]=np.linspace(0,1,int(sr*.5));fade[-int(sr*1.6):]=np.linspace(1,0,int(sr*1.6));out*=fade[:,None]
 out=np.tanh(out*1.4);out*=.76/max(.76,float(np.max(np.abs(out))))
 with wave.open('music_original.wav','wb') as f:f.setnchannels(2);f.setsampwidth(2);f.setframerate(sr);f.writeframes((out*32767).astype('<i2').tobytes())
def preview():
 frames=[]
 for i in range(7):
  im=scene(i,min(2,DUR[i]/2)).convert('RGB');im.thumbnail((270,480));frames.append(im)
 sheet=Image.new('RGB',(270*4,480*2),(222,225,219))
 for j,im in enumerate(frames):sheet.paste(im,((j%4)*270,(j//4)*480))
 sheet.save('preview.jpg',quality=90)
 for key,cap in VIDEOS.items():cap.release()
 print('Preview ready',flush=True)
def render():
 makeaudio()
 cmd=['ffmpeg','-y','-hide_banner','-loglevel','warning','-f','rawvideo','-vcodec','rawvideo','-pix_fmt','rgb24','-s',f'{W}x{H}','-r',str(FPS),'-i','pipe:0','-i','music_original.wav','-c:v','libx264','-preset','veryfast','-crf','19','-pix_fmt','yuv420p','-c:a','aac','-b:a','192k','-af','loudnorm=I=-17:TP=-1.5:LRA=9','-movflags','+faststart','-shortest','mesaOS_comercial_vertical_v1.mp4']
 proc=subprocess.Popen(cmd,stdin=subprocess.PIPE)
 prev=None
 for i,dur in enumerate(DUR):
  for f in range(round(dur*FPS)):
   t=f/FPS;im=scene(i,t)
   if prev is not None and t<.3:im=Image.blend(prev,im,ease(t/.3))
   if i==6 and t>dur-.45:
    im=Image.blend(im,Image.new('RGBA',(W,H),(18,20,20)),(t-(dur-.45))/.45*.5)
   proc.stdin.write(im.convert('RGB').tobytes())
  prev=im
  print(f'scene {i+1}/7 rendered at {START[i+1]:.1f}s',flush=True)
 proc.stdin.close()
 if proc.wait()!=0:raise RuntimeError('Encoder failed')
 for cap in VIDEOS.values():cap.release()
 print('Export complete',flush=True)
if __name__=='__main__':
 if '--preview' in sys.argv:preview()
 else:render()
